package com.alan.clients.component;

import com.alan.clients.Client;
import com.alan.clients.module.Module;
import org.reflections.Reflections;

import java.lang.reflect.Modifier;
import java.util.ArrayList;

/**
 * @author Alan
 * @since 01/27/2022
 */
public final class ComponentManager extends ArrayList<Component> {

    /**
     * Called on client start and when for some reason when we reinitialize
     */
    public void init() {
        final Reflections reflections = new Reflections("com.alan.clients.component.impl");

        reflections.getSubTypesOf(Component.class).forEach(clazz -> {
            try {
                if (!Modifier.isAbstract(clazz.getModifiers())) {
                    this.add(clazz.newInstance());
                }
            } catch (final Exception e) {
                e.printStackTrace();
            }
        });
        //Registers all components to the eventbus
        this.registerToEventBus();
    }

    public void registerToEventBus() {
        for (final Component component : this) {
            Client.INSTANCE.getEventBus().register(component);
        }
    }
}